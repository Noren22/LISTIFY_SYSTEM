<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="max-w-4xl mx-auto py-8">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2 class="text-2xl font-semibold">My Tasks</h2>
            <a href="<?php echo e(route('tasks.create')); ?>" class="btn btn-success">Add Task</a>
        </div>

        <!-- Success message -->
        <?php if(session('success')): ?>
            <div class="alert alert-success"><?php echo e(session('success')); ?></div>
        <?php endif; ?>

        <?php if($tasks->isEmpty()): ?>
            <div class="alert alert-info">No tasks found. Add your first task!</div>
        <?php else: ?>
            <table class="table table-bordered align-middle">
                <thead class="table-light">
                    <tr>
                        <th>Title</th>
                        <th>Description</th>
                        <th>Deadline</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $isOverdue = false;
                            if ($task->deadline) {
                                try {
                                    $timePart = $task->deadline_time ? \Carbon\Carbon::parse($task->deadline_time)->format('H:i:s') : '00:00:00';
                                    $due = \Carbon\Carbon::parse($task->deadline->format('Y-m-d') . ' ' . $timePart);
                                    $isOverdue = $due->isPast() && ! $task->is_completed;
                                } catch (Exception $e) {
                                    $isOverdue = $task->deadline->isPast() && ! $task->is_completed;
                                }
                            }
                        ?>
                        <tr class="<?php if($task->is_completed): ?> table-success <?php elseif($isOverdue): ?> table-danger <?php else: ?> table-warning <?php endif; ?>">
                            <td><?php echo e($task->title); ?></td>
                            <td><?php echo e($task->description); ?></td>
                            <td>
                                <?php if($task->deadline): ?>
                                    <?php echo e($task->deadline->format('M d, Y')); ?>

                                    <?php if($task->deadline_time): ?>
                                        · <?php echo e(\Carbon\Carbon::parse($task->deadline_time)->format('g:i A')); ?>

                                    <?php endif; ?>
                                <?php else: ?>
                                    -
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if($task->is_completed): ?>
                                    <span class="badge bg-success">Completed</span>
                                <?php elseif($isOverdue): ?>
                                    <span class="badge bg-danger">Overdue</span>
                                <?php else: ?>
                                    <span class="badge bg-warning text-dark">In Progress</span>
                                <?php endif; ?>
                            </td>
                            <td class="d-flex gap-2">
                                <!-- Toggle Completed -->
                                <form method="POST" action="<?php echo e(route('tasks.toggle', $task->id)); ?>">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PATCH'); ?>
                                    <button type="submit" class="btn btn-sm btn-outline-primary">
                                        <?php if($task->is_completed): ?> Mark In Progress <?php else: ?> Mark Completed <?php endif; ?>
                                    </button>
                                </form>

                                <!-- Edit -->
                                <a href="<?php echo e(route('tasks.edit', $task->id)); ?>" class="btn btn-sm btn-warning">Edit</a>

                                <!-- Delete -->
                                <form method="POST" action="<?php echo e(route('tasks.destroy', $task->id)); ?>" onsubmit="return confirm('Are you sure?')">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-sm btn-danger">Delete</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Users\Noren\OneDrive\문서\LISTIFY_SYSTEM\listify_system\resources\views/tasks/index.blade.php ENDPATH**/ ?>